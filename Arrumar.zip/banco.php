<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<pre>
<?php 

    $banco = new mysqli("localhost", "root", "", "prova.php");


    function buscarUsuario($usuario){
        global $banco;

        $q = "SELECT usuario, nome, senha FROM usuarios WHERE usuario='$usuario'";

        $busca = $banco->query($q);
        // echo var_dump($busca);

        return $busca;
    }


    function criarUsuario($usuario, $nome, $senha){
        global $banco;

        // $q = "INSERT INTO usuarios(cod, usuario, nome, senha) VALUES (NULL, 'pedroca', '', '122')";

        $senha = password_hash($senha, PASSWORD_DEFAULT);
        // createOnDB("usuarios(cod, usuario, nome, senha)", "(NULL, '$usuario', '$nome', '$senha')");

        $q = "INSERT INTO usuarios(cod, usuario, nome, data, senha) VALUES (NULL, '$usuario', '$nome', '$data' '$senha')";
        
        $resp = $banco->query($q);
        echo "Query: $q";
        echo var_dump($resp);

        function atualizarUsuario($usuario, $nome="", $senha="", $debug=false) : void {
            global $banco;
            
            if($nome != "" && $senha != ""){
                $senha = password_hash($senha, PASSWORD_DEFAULT);
                $set = "nome='$nome', senha='$senha'";
            }else if($nome != ""){
                $set = "nome='$nome'";
            }else if($senha != ""){
                $senha = password_hash($senha, PASSWORD_DEFAULT);
                $set = "senha='$senha'";
            }
    
            // $q = "UPDATE usuarios SET senha='$senha' WHERE usuario='$usuario'";
            $q = "UPDATE usuarios SET $set WHERE usuario='$usuario'";
            // updateOnDB("usuarios", $set, "usuario='$usuario'");
            // updateOnDB("usuarios", "nome='$nome', senha='$senha'", "usuario='$usuario'");
    
    
            $resp = $banco->query($q);
            
            if($debug){
                echo "Query: $q";
                echo var_dump($resp);
            }
        }
    
        function buscarUsuario(string $usuario, bool $debug=false) {
            global $banco;
    
            $q = "SELECT usuario, nome, senha FROM usuarios WHERE usuario='$usuario'";
    
            $busca = $banco->query($q);
            // echo var_dump($busca);
    
            return $busca;
        }
    
        function deletarUsuario(string $usuario, bool $debug=false) : void {
            global $banco;
    
            // deleteFromDB("usuarios", "usuario='$usuario'");
            $q = "DELETE FROM usuarios WHERE usuario='$usuario'";
            $resp = $banco->query($q);
    
            if($debug){
                echo "Query: $q";
                echo var_dump($resp);
            }
        }
        
    }
    
    
        
    
    ?>
    </pre>
    


