<form action="" method="post">
    <label for="">Usuario:</label>
    <input type="text" name="usuario" id="">

    <label for="">Senha:</label>
    <input type="text" name="senha" id="">

    <input type="submit" value="Login">

</form>